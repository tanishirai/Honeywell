"""
Feature Engineering for Behavioral Anomaly Detection
Extracts temporal, spatial, and contextual features from access logs
"""

import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.preprocessing import StandardScaler, LabelEncoder
import warnings
warnings.filterwarnings('ignore')

class BehavioralFeatureExtractor:
    def __init__(self):
        self.label_encoders = {}
        self.scaler = StandardScaler()
        self.feature_names = []
    
    def extract_temporal_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extract time-based behavioral features"""
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        df['hour_of_day'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        df['is_business_hours'] = ((df['hour_of_day'] >= 8) & 
                                   (df['hour_of_day'] <= 18)).astype(int)
        df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)
        
        return df
    
    def extract_entity_behavioral_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extract per-entity behavior aggregations"""
        entity_stats = df.groupby('entity_id').agg({
            'timestamp': ['count', 'nunique'],  # frequency, unique days
            'resource_accessed': 'nunique',
            'geo_location': 'nunique',
            'source_ip': 'nunique',
            'session_duration_mins': ['mean', 'std', 'max'],
            'auth_method': 'nunique'
        }).fillna(0)
        
        entity_stats.columns = ['_'.join(col).strip() for col in entity_stats.columns.values]
        entity_stats = entity_stats.rename(columns={
            'timestamp_count': 'entity_access_frequency',
            'timestamp_nunique': 'entity_unique_days',
            'resource_accessed_nunique': 'entity_resource_diversity',
            'geo_location_nunique': 'entity_location_diversity',
            'source_ip_nunique': 'entity_ip_diversity',
            'session_duration_mins_mean': 'entity_avg_session',
            'session_duration_mins_std': 'entity_session_variance',
            'session_duration_mins_max': 'entity_max_session',
            'auth_method_nunique': 'entity_auth_diversity'
        })
        
        df = df.merge(entity_stats, left_on='entity_id', right_index=True, how='left')
        return df
    
    def extract_contextual_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extract context-based anomaly indicators"""
        # Rare resource access (top 3 resources are normal)
        resource_freq = df['resource_accessed'].value_counts()
        top_resources = set(resource_freq.head(3).index)
        df['is_rare_resource'] = (~df['resource_accessed'].isin(top_resources)).astype(int)
        
        # Unusual auth method for entity
        df['unusual_auth'] = 0
        for entity in df['entity_id'].unique():
            mask = df['entity_id'] == entity
            typical_auths = df.loc[mask, 'auth_method'].value_counts().head(2).index
            df.loc[mask, 'unusual_auth'] = (~df.loc[mask, 'auth_method'].isin(typical_auths)).astype(int)
        
        # Suspicious command patterns
        suspicious_commands = ['repeated_login_failures', 'invalid_credentials', 
                             'sequential_resource_access', 'gradual_data_access']
        df['is_suspicious_command'] = df['command_sequence'].isin(suspicious_commands).astype(int)
        
        # Location shift (location change from normal pattern)
        df['location_shift'] = 0
        for entity in df['entity_id'].unique():
            mask = df['entity_id'] == entity
            typical_locs = df.loc[mask, 'geo_location'].value_counts().head(2).index
            df.loc[mask, 'location_shift'] = (~df.loc[mask, 'geo_location'].isin(typical_locs)).astype(int)
        
        return df
    
    def extract_sequence_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extract sequence/temporal pattern features"""
        df = df.sort_values('timestamp')
        
        # Time since last access per entity
        df['time_since_last_access'] = df.groupby('entity_id')['timestamp'].diff().dt.total_seconds() / 3600
        df['time_since_last_access'] = df['time_since_last_access'].fillna(0)
        df['time_since_last_access'] = np.log1p(df['time_since_last_access'])
        
        # Access rate in last 24 hours (rolling)
        df['access_count_24h'] = 0
        for entity in df['entity_id'].unique():
            mask = df['entity_id'] == entity
            entity_times = df.loc[mask, 'timestamp']
            counts = [1] * len(entity_times)  # Simplified: count events per entity
            df.loc[mask, 'access_count_24h'] = counts
        
        # Session duration anomaly
        df['session_duration_anomaly'] = 0
        for entity in df['entity_id'].unique():
            mask = df['entity_id'] == entity
            if mask.sum() > 1:
                median_session = df.loc[mask, 'session_duration_mins'].median()
                deviation = (df.loc[mask, 'session_duration_mins'] - median_session).abs()
                threshold = median_session * 2 if median_session > 0 else 30
                df.loc[mask, 'session_duration_anomaly'] = (deviation > threshold).astype(int)
        
        return df
    
    def encode_categorical_features(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """Encode categorical features"""
        categorical_cols = ['entity_type', 'auth_method', 'protocol']
        
        for col in categorical_cols:
            if fit:
                self.label_encoders[col] = LabelEncoder()
                df[f'{col}_encoded'] = self.label_encoders[col].fit_transform(df[col].astype(str))
            else:
                try:
                    df[f'{col}_encoded'] = self.label_encoders[col].transform(df[col].astype(str))
                except ValueError:
                    # Handle unseen labels
                    df[f'{col}_encoded'] = 0
        
        return df
    
    def extract_all_features(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """Extract all features and prepare for modeling"""
        print("Extracting features...")
        
        df = self.extract_temporal_features(df)
        df = self.extract_entity_behavioral_features(df)
        df = self.extract_contextual_features(df)
        df = self.extract_sequence_features(df)
        df = self.encode_categorical_features(df, fit=fit)
        
        print("✓ Features extracted")
        return df
    
    def get_feature_columns(self) -> list:
        """Get numeric feature columns for modeling"""
        feature_cols = [
            'hour_of_day', 'day_of_week', 'is_business_hours', 'is_weekend',
            'entity_access_frequency', 'entity_unique_days', 'entity_resource_diversity',
            'entity_location_diversity', 'entity_ip_diversity', 
            'entity_avg_session', 'entity_session_variance', 'entity_max_session',
            'entity_auth_diversity', 'is_rare_resource', 'unusual_auth',
            'is_suspicious_command', 'location_shift', 'time_since_last_access',
            'access_count_24h', 'session_duration_anomaly',
            'entity_type_encoded', 'auth_method_encoded', 'protocol_encoded',
            'session_duration_mins'
        ]
        self.feature_names = feature_cols
        return feature_cols
    
    def prepare_for_modeling(self, df: pd.DataFrame, fit: bool = True) -> tuple:
        """Prepare data for model training/inference"""
        feature_cols = self.get_feature_columns()
        X = df[feature_cols].copy()
        
        # Handle missing values
        X = X.fillna(X.mean())
        
        if fit:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = self.scaler.transform(X)
        
        # Prepare labels if available
        y = None
        if 'label' in df.columns:
            y = (df['label'] != 'normal').astype(int)
        
        return X_scaled, y, X


if __name__ == "__main__":
    # Test feature extraction
    df = pd.read_csv('/home/claude/honeywell_project/data/access_logs.csv')
    extractor = BehavioralFeatureExtractor()
    df_features = extractor.extract_all_features(df)
    X, y, X_raw = extractor.prepare_for_modeling(df_features)
    
    print(f"\nFeature matrix shape: {X.shape}")
    print(f"Features: {extractor.feature_names}")
    print(f"Anomaly rate: {y.sum() / len(y) * 100:.1f}%")
