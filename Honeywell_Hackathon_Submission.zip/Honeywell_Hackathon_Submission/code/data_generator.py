"""
Synthetic Data Generator for AI-Powered Behavioral Anomaly Detection System
Generates realistic access logs with normal and anomalous patterns
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random
from typing import Tuple, List

class SyntheticAccessLogGenerator:
    def __init__(self, seed: int = 42):
        np.random.seed(seed)
        random.seed(seed)
        
        # Resource pools
        self.resources = ['db_read', 'file_export', 'api_call', 'config_access', 
                         'user_mgmt', 'report_gen', 'db_write', 'log_access']
        self.locations = ['US-East', 'US-West', 'EU-Central', 'APAC', 'VPN', 'Office', 'Remote']
        self.auth_methods = ['password', 'token', 'certificate', 'biometric']
        self.protocols = ['SSH', 'HTTP', 'HTTPS', 'SFTP', 'RDP']
        
        # Realistic user patterns
        self.normal_users = [f'user_{i:04d}' for i in range(50)]
        self.service_accounts = [f'svc_{i:03d}' for i in range(10)]
        self.admin_accounts = [f'admin_{i:02d}' for i in range(5)]
        
    def generate_normal_baseline(self, n_samples: int = 2000) -> pd.DataFrame:
        """
        Generate normal baseline behavior: habitual access patterns with regular times,
        consistent locations, typical resources
        """
        logs = []
        base_time = datetime.now() - timedelta(days=30)
        
        for i in range(n_samples):
            user = random.choice(self.normal_users + self.service_accounts)
            
            # Normal: recurring login hours (business hours + consistent patterns)
            day_offset = (i // 20) % 30  # Cycles through 30 days
            hour = random.choice([8, 9, 10, 14, 15, 16])  # Business hours
            minute = random.randint(0, 59)
            
            timestamp = base_time + timedelta(days=day_offset, hours=hour, minutes=minute)
            
            # Normal: limited locations
            location = random.choice(self.locations[:5])  # Known locations
            
            # Normal: expected resources
            resource = random.choice(self.resources[:4])
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp.isoformat(),
                'source_ip': f"10.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
                'geo_location': location,
                'resource_accessed': resource,
                'auth_method': random.choice(self.auth_methods),
                'protocol': random.choice(self.protocols),
                'session_duration_mins': random.randint(5, 120),
                'command_sequence': 'normal',
                'device_fingerprint': f"device_{hash(user) % 100}",
                'label': 'normal'
            })
        
        return pd.DataFrame(logs)
    
    def generate_brute_force(self, n_samples: int = 150) -> pd.DataFrame:
        """
        Rapid repeated failed auth attempts from one source in a short window
        """
        logs = []
        base_time = datetime.now() - timedelta(days=15)
        
        for i in range(n_samples):
            # Multiple attempts in short window
            attempt_block = i // 10
            attack_user = random.choice(self.normal_users)
            
            timestamp = base_time + timedelta(days=attempt_block % 15, 
                                             seconds=random.randint(0, 300))
            
            logs.append({
                'entity_id': attack_user,
                'entity_type': 'user',
                'timestamp': timestamp.isoformat(),
                'source_ip': f"192.168.{random.randint(1,255)}.{random.randint(1,255)}",
                'geo_location': 'Unknown',
                'resource_accessed': 'login',
                'auth_method': 'password',
                'protocol': 'SSH',
                'session_duration_mins': 0,  # Failed attempts
                'command_sequence': 'repeated_login_failures',
                'device_fingerprint': 'unknown_device',
                'label': 'brute_force'
            })
        
        return pd.DataFrame(logs)
    
    def generate_impossible_travel(self, n_samples: int = 80) -> pd.DataFrame:
        """
        Same user logging in from geographically distant locations in impossible time window
        """
        logs = []
        base_time = datetime.now() - timedelta(days=20)
        
        for i in range(n_samples // 2):
            user = random.choice(self.normal_users)
            
            # First location
            timestamp1 = base_time + timedelta(days=i, hours=random.randint(0, 23))
            loc1 = 'US-East'
            ip1 = f"10.{random.randint(1,100)}.{random.randint(1,255)}.{random.randint(1,255)}"
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp1.isoformat(),
                'source_ip': ip1,
                'geo_location': loc1,
                'resource_accessed': random.choice(self.resources),
                'auth_method': 'token',
                'protocol': 'HTTPS',
                'session_duration_mins': random.randint(10, 60),
                'command_sequence': 'normal',
                'device_fingerprint': f"device_{hash(user) % 100}",
                'label': 'impossible_travel'
            })
            
            # Second location 5000 miles away, 30 mins later (physically impossible)
            timestamp2 = timestamp1 + timedelta(minutes=30)
            loc2 = random.choice(['EU-Central', 'APAC'])
            ip2 = f"200.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp2.isoformat(),
                'source_ip': ip2,
                'geo_location': loc2,
                'resource_accessed': random.choice(self.resources),
                'auth_method': 'token',
                'protocol': 'HTTPS',
                'session_duration_mins': random.randint(10, 60),
                'command_sequence': 'normal',
                'device_fingerprint': f"device_different_{hash(user) % 100}",
                'label': 'impossible_travel'
            })
        
        return pd.DataFrame(logs)
    
    def generate_credential_stuffing(self, n_samples: int = 120) -> pd.DataFrame:
        """
        Many user accounts, few source IPs, high failure rate
        """
        logs = []
        base_time = datetime.now() - timedelta(days=10)
        attack_ips = [f"203.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}" 
                     for _ in range(3)]
        
        for i in range(n_samples):
            user = random.choice(self.normal_users)
            
            timestamp = base_time + timedelta(days=i % 10, 
                                             seconds=random.randint(0, 86400))
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp.isoformat(),
                'source_ip': random.choice(attack_ips),
                'geo_location': 'VPN',
                'resource_accessed': 'login',
                'auth_method': 'password',
                'protocol': 'HTTPS',
                'session_duration_mins': random.randint(0, 5),
                'command_sequence': 'invalid_credentials',
                'device_fingerprint': 'rotating_devices',
                'label': 'credential_stuffing'
            })
        
        return pd.DataFrame(logs)
    
    def generate_lateral_movement(self, n_samples: int = 100) -> pd.DataFrame:
        """
        Entity accessing unusual sequence/breadth of resources, typically after initial breach
        """
        logs = []
        base_time = datetime.now() - timedelta(days=12)
        
        for i in range(n_samples):
            user = random.choice(self.admin_accounts + self.service_accounts)
            
            timestamp = base_time + timedelta(days=i % 12, hours=random.randint(0, 23))
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp.isoformat(),
                'source_ip': f"10.{random.randint(100,200)}.{random.randint(1,255)}.{random.randint(1,255)}",
                'geo_location': 'Office',
                'resource_accessed': random.choice(self.resources),  # Broad access
                'auth_method': 'certificate',
                'protocol': 'SSH',
                'session_duration_mins': random.randint(30, 300),
                'command_sequence': 'sequential_resource_access',
                'device_fingerprint': f"device_{hash(user) % 100}",
                'label': 'lateral_movement'
            })
        
        return pd.DataFrame(logs)
    
    def generate_device_spoofing(self, n_samples: int = 90) -> pd.DataFrame:
        """
        Known user from known location but device fingerprint mismatch or suspicious
        """
        logs = []
        base_time = datetime.now() - timedelta(days=18)
        
        for i in range(n_samples):
            user = random.choice(self.normal_users)
            
            timestamp = base_time + timedelta(days=i % 18, hours=random.randint(0, 23))
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp.isoformat(),
                'source_ip': f"10.{random.randint(1,100)}.{random.randint(1,255)}.{random.randint(1,255)}",
                'geo_location': 'Office',  # Normal location
                'resource_accessed': random.choice(self.resources),
                'auth_method': 'token',
                'protocol': 'HTTPS',
                'session_duration_mins': random.randint(10, 60),
                'command_sequence': 'normal',
                'device_fingerprint': f"suspicious_device_{i}",  # Mismatched
                'label': 'device_spoofing'
            })
        
        return pd.DataFrame(logs)
    
    def generate_low_slow_exfiltration(self, n_samples: int = 110) -> pd.DataFrame:
        """
        Gradual small data access over extended periods, hard to detect
        """
        logs = []
        base_time = datetime.now() - timedelta(days=25)
        
        for i in range(n_samples):
            user = random.choice(self.service_accounts)
            
            # Spread over days/weeks
            timestamp = base_time + timedelta(days=i // 4, 
                                             hours=random.choice([1, 3, 5, 23]),
                                             minutes=random.randint(0, 59))
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp.isoformat(),
                'source_ip': f"10.{random.randint(1,50)}.{random.randint(1,255)}.{random.randint(1,255)}",
                'geo_location': 'Remote',
                'resource_accessed': 'db_read',
                'auth_method': 'token',
                'protocol': 'HTTPS',
                'session_duration_mins': random.randint(2, 10),  # Small sessions
                'command_sequence': 'gradual_data_access',
                'device_fingerprint': f"device_{hash(user) % 100}",
                'label': 'low_slow_exfiltration'
            })
        
        return pd.DataFrame(logs)
    
    def generate_insider_drift(self, n_samples: int = 85) -> pd.DataFrame:
        """
        Legitimate entity slowly expanding privilege/resource access over time
        """
        logs = []
        base_time = datetime.now() - timedelta(days=30)
        
        for i in range(n_samples):
            user = random.choice(self.normal_users)
            
            timestamp = base_time + timedelta(days=i // 3, hours=random.choice([9, 10, 14, 15]))
            
            # Gradually access more restricted resources
            resource_pool = self.resources[:5] if (i < n_samples // 2) else self.resources
            
            logs.append({
                'entity_id': user,
                'entity_type': 'user',
                'timestamp': timestamp.isoformat(),
                'source_ip': f"10.{random.randint(1,100)}.{random.randint(1,255)}.{random.randint(1,255)}",
                'geo_location': 'Office',
                'resource_accessed': random.choice(resource_pool),
                'auth_method': 'password',
                'protocol': 'HTTPS',
                'session_duration_mins': random.randint(15, 120),
                'command_sequence': 'expanding_access_pattern',
                'device_fingerprint': f"device_{hash(user) % 100}",
                'label': 'insider_drift'
            })
        
        return pd.DataFrame(logs)
    
    def generate_dataset(self, n_normal: int = 2000) -> pd.DataFrame:
        """Generate complete dataset with all patterns"""
        print("Generating synthetic access logs...")
        
        dfs = [
            self.generate_normal_baseline(n_normal),
            self.generate_brute_force(150),
            self.generate_impossible_travel(80),
            self.generate_credential_stuffing(120),
            self.generate_lateral_movement(100),
            self.generate_device_spoofing(90),
            self.generate_low_slow_exfiltration(110),
            self.generate_insider_drift(85)
        ]
        
        df = pd.concat(dfs, ignore_index=True)
        df = df.sort_values('timestamp').reset_index(drop=True)
        
        print(f"✓ Generated {len(df)} total logs")
        print(f"  - Normal: {(df['label'] == 'normal').sum()}")
        print(f"  - Anomalies: {(df['label'] != 'normal').sum()}")
        
        return df


if __name__ == "__main__":
    generator = SyntheticAccessLogGenerator(seed=42)
    dataset = generator.generate_dataset(n_normal=2000)
    dataset.to_csv('/home/claude/honeywell_project/data/access_logs.csv', index=False)
    print(f"\nDataset saved to data/access_logs.csv")
