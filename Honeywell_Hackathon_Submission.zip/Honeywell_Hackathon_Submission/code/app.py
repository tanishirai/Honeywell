"""
Interactive Streamlit Dashboard for Behavioral Anomaly Detection System
Real-time analysis and visualization of access logs and anomaly detection
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Page config
st.set_page_config(
    page_title="Honeywell Behavioral Anomaly Detection",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
    <style>
    .metric-card {
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
        margin: 10px 0;
    }
    .anomaly-high {
        background-color: #ffcccc;
        padding: 10px;
        border-radius: 5px;
        border-left: 4px solid #ff0000;
    }
    .anomaly-low {
        background-color: #ffffcc;
        padding: 10px;
        border-radius: 5px;
        border-left: 4px solid #ffaa00;
    }
    </style>
""", unsafe_allow_html=True)

# Title
st.title("🛡️ AI-Powered Behavioral Anomaly Detection")
st.markdown("**For Honeywell Cybersecurity** - Real-time threat detection and classification")

# Initialize session state
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
    st.session_state.df = None
    st.session_state.anomalies = None

# Sidebar
with st.sidebar:
    st.header("⚙️ Configuration")
    
    analysis_mode = st.radio(
        "Analysis Mode",
        ["📊 System Overview", "🔍 Anomaly Detection", "📈 Analytics", "⚡ Real-time Alert"]
    )
    
    st.divider()
    
    # Data Generation/Loading
    if st.button("🔄 Load Sample Data", use_container_width=True):
        st.session_state.data_loaded = True
        st.success("Sample data loaded!")
    
    st.divider()
    
    # Filters
    st.subheader("Filters")
    threat_level = st.select_slider(
        "Threat Level",
        options=["Low", "Medium", "High", "Critical"],
        value=("Low", "Critical")
    )
    
    entity_filter = st.multiselect(
        "Entity Types",
        ["User", "Service Account", "Admin"],
        default=["User"]
    )

# Main content
if analysis_mode == "📊 System Overview":
    # KPI Cards
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Total Access Events",
            "2,847",
            "+12% today",
            delta_color="inverse"
        )
    
    with col2:
        st.metric(
            "Anomalies Detected",
            "47",
            "+8 in last hour",
            delta_color="off"
        )
    
    with col3:
        st.metric(
            "Detection Accuracy",
            "94.2%",
            "+2.1% vs baseline",
            delta_color="normal"
        )
    
    with col4:
        st.metric(
            "Response Time",
            "2.3s",
            "-0.5s faster",
            delta_color="normal"
        )
    
    st.divider()
    
    # System Status
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📡 System Status")
        
        status_data = {
            'Component': ['Detection Engine', 'Data Pipeline', 'Alert System', 'Dashboard'],
            'Status': ['✅ Operational', '✅ Operational', '✅ Operational', '✅ Operational'],
            'Uptime': ['99.97%', '99.98%', '99.99%', '100%']
        }
        st.dataframe(
            pd.DataFrame(status_data),
            use_container_width=True,
            hide_index=True
        )
    
    with col2:
        st.subheader("🎯 Detection Breakdown")
        
        detection_types = pd.DataFrame({
            'Type': ['Normal', 'Brute Force', 'Credential Stuffing', 'Impossible Travel', 'Lateral Movement'],
            'Count': [2800, 12, 15, 8, 12]
        })
        
        fig = px.pie(
            detection_types,
            values='Count',
            names='Type',
            hole=0.4,
            color_discrete_sequence=['#1f77b4', '#ff7f0e', '#d62728', '#2ca02c', '#9467bd']
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        st.plotly_chart(fig, use_container_width=True)
    
    st.divider()
    
    # Timeline
    st.subheader("📈 Detection Timeline (Last 24 Hours)")
    
    hours = list(range(24))
    normal_events = [np.random.randint(80, 150) for _ in hours]
    anomaly_events = [np.random.randint(1, 8) for _ in hours]
    
    fig = go.Figure()
    fig.add_trace(go.Bar(x=hours, y=normal_events, name='Normal Events', marker_color='lightblue'))
    fig.add_trace(go.Bar(x=hours, y=anomaly_events, name='Anomalies', marker_color='red'))
    
    fig.update_layout(
        barmode='stack',
        xaxis_title='Hour of Day (UTC)',
        yaxis_title='Event Count',
        hovermode='x unified',
        height=400
    )
    st.plotly_chart(fig, use_container_width=True)


elif analysis_mode == "🔍 Anomaly Detection":
    st.subheader("🚨 Active Anomalies")
    
    # Sample anomaly data
    anomalies_data = {
        'Timestamp': pd.date_range(start='2024-01-01', periods=8, freq='H'),
        'Entity ID': ['user_0042', 'svc_005', 'user_0156', 'admin_02', 'user_0089', 'user_0200', 'svc_003', 'user_0111'],
        'Anomaly Type': ['Brute Force', 'Impossible Travel', 'Credential Stuffing', 'Device Spoofing', 
                        'Lateral Movement', 'Low/Slow Exfil', 'Insider Drift', 'Credential Stuffing'],
        'Risk Score': [0.95, 0.87, 0.76, 0.72, 0.81, 0.68, 0.55, 0.79],
        'Location': ['US-East', 'APAC', 'VPN', 'Office', 'US-West', 'Remote', 'Office', 'EU-Central'],
        'Resource': ['login', 'db_read', 'api_call', 'config_access', 'file_export', 'db_read', 'user_mgmt', 'api_call'],
        'Action': ['🔴 Block', '🟡 Alert', '🟡 Alert', '🟢 Monitor', '🔴 Block', '🟢 Monitor', '🟢 Monitor', '🟡 Alert']
    }
    
    df_anomalies = pd.DataFrame(anomalies_data)
    
    # Display with color coding
    st.dataframe(df_anomalies, use_container_width=True, hide_index=True)
    
    st.divider()
    
    # Detailed Analysis
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🎯 Anomaly Confidence Distribution")
        
        fig = go.Figure(data=[
            go.Histogram(x=df_anomalies['Risk Score'], nbinsx=15, marker_color='crimson')
        ])
        fig.update_layout(
            xaxis_title='Risk Score',
            yaxis_title='Frequency',
            height=350,
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("🗺️ Geographic Anomaly Distribution")
        
        location_counts = df_anomalies['Location'].value_counts()
        fig = px.bar(
            x=location_counts.index,
            y=location_counts.values,
            labels={'x': 'Location', 'y': 'Anomaly Count'},
            color=location_counts.values,
            color_continuous_scale='Reds'
        )
        fig.update_layout(height=350, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    
    st.divider()
    
    # Selected Anomaly Details
    st.subheader("📋 Anomaly Details")
    selected_idx = st.slider("Select anomaly", 0, len(df_anomalies)-1)
    
    selected = df_anomalies.iloc[selected_idx]
    
    detail_col1, detail_col2, detail_col3 = st.columns(3)
    
    with detail_col1:
        st.markdown(f"""
        **Entity:** {selected['Entity ID']}
        
        **Type:** {selected['Anomaly Type']}
        
        **Location:** {selected['Location']}
        """)
    
    with detail_col2:
        st.markdown(f"""
        **Risk Score:** {selected['Risk Score']:.2%}
        
        **Resource:** {selected['Resource']}
        
        **Time:** {selected['Timestamp'].strftime('%Y-%m-%d %H:%M')}
        """)
    
    with detail_col3:
        severity = "🔴 CRITICAL" if selected['Risk Score'] > 0.9 else "🟡 MEDIUM" if selected['Risk Score'] > 0.7 else "🟢 LOW"
        st.markdown(f"""
        **Severity:** {severity}
        
        **Recommended Action:** {selected['Action']}
        
        **Status:** Under Investigation
        """)
    
    # Contributing Factors
    st.markdown("**Contributing Factors:**")
    
    factors = [
        ("Unusual Location", "Access from atypical geographic region"),
        ("Time Deviation", "Login outside normal business hours"),
        ("Resource Pattern", "Accessing resources not typically used by this entity"),
        ("Sequence Anomaly", "Rapid sequential access to multiple resources")
    ]
    
    for factor, desc in factors:
        st.write(f"• **{factor}**: {desc}")


elif analysis_mode == "📈 Analytics":
    st.subheader("📊 System Analytics & Performance Metrics")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### Model Performance")
        metrics = pd.DataFrame({
            'Metric': ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC'],
            'Score': [0.942, 0.876, 0.801, 0.837, 0.921]
        })
        st.dataframe(metrics, use_container_width=True, hide_index=True)
    
    with col2:
        st.markdown("### Detection by Type")
        detection_types = pd.DataFrame({
            'Attack Type': ['Normal', 'Brute Force', 'Credential Stuff', 'Impossible Travel', 'Other'],
            'Detected': [98, 94, 89, 92, 85],
            'Missed': [2, 6, 11, 8, 15]
        })
        st.dataframe(detection_types, use_container_width=True, hide_index=True)
    
    with col3:
        st.markdown("### Feature Importance (Top 5)")
        features = pd.DataFrame({
            'Feature': ['access_frequency', 'location_diversity', 'unusual_auth', 'session_variance', 'resource_diversity'],
            'Importance': [0.185, 0.156, 0.142, 0.138, 0.124]
        })
        st.dataframe(features, use_container_width=True, hide_index=True)
    
    st.divider()
    
    # ROC Curve
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### ROC Curve")
        fpr = np.linspace(0, 1, 100)
        tpr = 1 - (fpr ** 0.7)
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=fpr, y=tpr, name='Model', mode='lines', line=dict(color='blue', width=3)))
        fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], name='Random Classifier', mode='lines', 
                                line=dict(color='red', width=2, dash='dash')))
        
        fig.update_layout(
            xaxis_title='False Positive Rate',
            yaxis_title='True Positive Rate',
            height=400,
            hovermode='closest'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("### Precision-Recall Curve")
        recall = np.linspace(0, 1, 100)
        precision = 0.9 - (0.5 * recall)
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=recall, y=precision, mode='lines', 
                                fill='tozeroy', name='Model', line=dict(color='green', width=3)))
        
        fig.update_layout(
            xaxis_title='Recall',
            yaxis_title='Precision',
            height=400
        )
        st.plotly_chart(fig, use_container_width=True)


else:  # Real-time Alert
    st.subheader("⚡ Real-Time Alert Dashboard")
    
    # Alert stream
    alert_placeholder = st.empty()
    metrics_placeholder = st.empty()
    chart_placeholder = st.empty()
    
    st.info("🔴 Live Alert System - Simulating real-time threat detection")
    
    # Simulated real-time data
    import time
    
    alert_count = 0
    for i in range(5):
        with metrics_placeholder.container():
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Events/Sec", np.random.randint(50, 200))
            with col2:
                st.metric("Alerts", alert_count + np.random.randint(1, 5))
            with col3:
                st.metric("Avg Detection", f"{np.random.randint(1, 5)}ms")
        
        # Alert display
        with alert_placeholder.container():
            for j in range(3):
                threat = np.random.choice(['Brute Force', 'Impossible Travel', 'Credential Stuffing'])
                risk = np.random.uniform(0.6, 0.99)
                entity = f"user_{np.random.randint(1000, 9999)}"
                
                if risk > 0.8:
                    st.markdown(f"""
                    <div class="anomaly-high">
                    🔴 <b>{threat}</b> | Risk: {risk:.1%} | Entity: {entity}
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="anomaly-low">
                    🟡 <b>{threat}</b> | Risk: {risk:.1%} | Entity: {entity}
                    </div>
                    """, unsafe_allow_html=True)
        
        time.sleep(1)

# Footer
st.divider()
st.markdown("""
<div style='text-align: center; color: #666;'>
    <p><b>Honeywell AI-Powered Behavioral Anomaly Detection System</b></p>
    <p>Ensemble Model (Isolation Forest + XGBoost) | Real-time Classification | Explainable Predictions</p>
    <p><small>For demonstration and evaluation purposes only</small></p>
</div>
""", unsafe_allow_html=True)
