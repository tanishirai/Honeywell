"""
Honeywell AI-Powered Behavioral Anomaly Detection System
"""

__version__ = "1.0.0"
__author__ = "Tanishi Rai"