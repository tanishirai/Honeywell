"""
Ensemble Anomaly Detection Model
Combines Isolation Forest (unsupervised) + XGBoost (supervised classification)
"""

import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.model_selection import train_test_split
from sklearn.metrics import (classification_report, confusion_matrix, 
                             roc_auc_score, precision_recall_curve, roc_curve)
import xgboost as xgb
import warnings
warnings.filterwarnings('ignore')

class EnsembleAnomalyDetector:
    def __init__(self, contamination: float = 0.15):
        """
        Initialize ensemble model
        
        Args:
            contamination: Expected anomaly rate for Isolation Forest
        """
        self.isolation_forest = IsolationForest(
            contamination=contamination,
            random_state=42,
            n_estimators=100
        )
        
        self.xgboost_classifier = xgb.XGBClassifier(
            n_estimators=100,
            max_depth=6,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            scale_pos_weight=5,  # Handle class imbalance
            eval_metric='aucpr',
            verbosity=0
        )
        
        self.is_trained = False
        self.feature_importances = None
        self.metrics = {}
    
    def fit(self, X_train: np.ndarray, y_train: np.ndarray = None):
        """
        Train ensemble model
        
        Args:
            X_train: Feature matrix
            y_train: True labels (if available)
        """
        print("Training Isolation Forest...")
        # Isolation Forest for unsupervised anomaly detection
        if_predictions = self.isolation_forest.fit_predict(X_train)
        if_scores = self.isolation_forest.score_samples(X_train)
        
        print("Training XGBoost classifier...")
        # If labels provided, use for supervised learning
        if y_train is not None:
            # Split data for validation
            X_t, X_val, y_t, y_val = train_test_split(
                X_train, y_train, test_size=0.2, random_state=42, stratify=y_train
            )
            
            # Add Isolation Forest scores as feature
            if_scores_t = self.isolation_forest.score_samples(X_t)
            if_scores_val = self.isolation_forest.score_samples(X_val)
            
            X_t_ensemble = np.column_stack([X_t, if_scores_t])
            X_val_ensemble = np.column_stack([X_val, if_scores_val])
            
            # Train XGBoost with validation
            self.xgboost_classifier.fit(
                X_t_ensemble, y_t,
                eval_set=[(X_val_ensemble, y_val)],
                verbose=False
            )
            
            # Evaluate
            y_pred = self.xgboost_classifier.predict(X_val_ensemble)
            y_proba = self.xgboost_classifier.predict_proba(X_val_ensemble)[:, 1]
            
            self.metrics['validation_auc'] = roc_auc_score(y_val, y_proba)
            self.metrics['validation_precision_recall'] = precision_recall_curve(y_val, y_proba)
            
            print(f"✓ XGBoost trained - Validation AUC: {self.metrics['validation_auc']:.3f}")
        
        # Feature importances
        self.feature_importances = self.xgboost_classifier.feature_importances_
        
        self.is_trained = True
        print("✓ Ensemble model training complete")
    
    def predict(self, X: np.ndarray, return_scores: bool = False) -> tuple:
        """
        Predict anomalies using ensemble
        
        Args:
            X: Feature matrix
            return_scores: If True, return anomaly scores
        
        Returns:
            predictions: Binary predictions (0=normal, 1=anomaly)
            anomaly_scores: Anomaly scores (optional)
        """
        if not self.is_trained:
            raise ValueError("Model not trained yet")
        
        # Isolation Forest scores
        if_scores = self.isolation_forest.score_samples(X)
        X_ensemble = np.column_stack([X, if_scores])
        
        # XGBoost predictions
        predictions = self.xgboost_classifier.predict(X_ensemble)
        anomaly_scores = self.xgboost_classifier.predict_proba(X_ensemble)[:, 1]
        
        if return_scores:
            return predictions, anomaly_scores, if_scores
        return predictions, anomaly_scores
    
    def classify_anomaly(self, X: np.ndarray, anomaly_scores: np.ndarray) -> np.ndarray:
        """
        Classify type of anomaly for detected anomalies
        
        For demonstration, uses anomaly score patterns to categorize
        """
        categories = []
        
        for score in anomaly_scores:
            if score < 0.3:
                categories.append('normal')
            elif score < 0.5:
                categories.append('suspicious')
            elif score < 0.7:
                categories.append('anomaly_low_confidence')
            elif score < 0.85:
                categories.append('anomaly_medium_confidence')
            else:
                categories.append('anomaly_high_confidence')
        
        return np.array(categories)
    
    def get_feature_importance(self, feature_names: list) -> pd.DataFrame:
        """Get feature importance for explainability"""
        if self.feature_importances is None:
            return None
        
        # Only use importances for original features (exclude IF scores)
        importances = self.feature_importances[:len(feature_names)]
        
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        return importance_df
    
    def save(self, filepath: str):
        """Save model to disk"""
        model_data = {
            'isolation_forest': self.isolation_forest,
            'xgboost': self.xgboost_classifier,
            'feature_importances': self.feature_importances,
            'metrics': self.metrics
        }
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
        print(f"✓ Model saved to {filepath}")
    
    def load(self, filepath: str):
        """Load model from disk"""
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        self.isolation_forest = model_data['isolation_forest']
        self.xgboost_classifier = model_data['xgboost']
        self.feature_importances = model_data['feature_importances']
        self.metrics = model_data['metrics']
        self.is_trained = True
        print(f"✓ Model loaded from {filepath}")


class AnomalyExplainer:
    """Explain individual anomaly predictions"""
    
    def __init__(self, feature_names: list, scaler=None):
        self.feature_names = feature_names
        self.scaler = scaler
    
    def explain_prediction(self, X_instance: np.ndarray, prediction: int, 
                          score: float) -> dict:
        """
        Explain why an instance was flagged as anomaly
        
        Args:
            X_instance: Single feature vector
            prediction: Model prediction (0/1)
            score: Anomaly score
        
        Returns:
            explanation: Dict with contributing factors
        """
        explanation = {
            'prediction': 'ANOMALY' if prediction == 1 else 'NORMAL',
            'confidence': f"{score:.2%}",
            'contributing_factors': []
        }
        
        # Identify features with extreme values
        for i, feature_name in enumerate(self.feature_names):
            if X_instance[i] > 2.0 or X_instance[i] < -2.0:  # > 2 std devs
                explanation['contributing_factors'].append({
                    'feature': feature_name,
                    'value': f"{X_instance[i]:.2f}",
                    'deviation': 'HIGH' if X_instance[i] > 0 else 'LOW'
                })
        
        if not explanation['contributing_factors']:
            explanation['contributing_factors'] = [
                {'feature': 'overall_pattern', 'value': 'unusual_combination', 'deviation': 'PATTERN'}
            ]
        
        return explanation


if __name__ == "__main__":
    # Test ensemble model
    from feature_engineering import BehavioralFeatureExtractor
    
    print("Loading data...")
    df = pd.read_csv('/home/claude/honeywell_project/data/access_logs.csv')
    
    print("Extracting features...")
    extractor = BehavioralFeatureExtractor()
    df_features = extractor.extract_all_features(df)
    X, y, X_raw = extractor.prepare_for_modeling(df_features)
    
    print("Splitting data...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print("\nTraining ensemble model...")
    detector = EnsembleAnomalyDetector(contamination=0.15)
    detector.fit(X_train, y_train)
    
    print("\nEvaluating on test set...")
    y_pred, y_scores = detector.predict(X_test)
    
    print(f"\nAUC Score: {roc_auc_score(y_test, y_scores):.3f}")
    print(f"\nClassification Report:")
    print(classification_report(y_test, y_pred))
    
    # Feature importance
    importance_df = detector.get_feature_importance(extractor.feature_names)
    print(f"\nTop 10 Important Features:")
    print(importance_df.head(10))
    
    # Save model
    detector.save('/home/claude/honeywell_project/models/ensemble_detector.pkl')
