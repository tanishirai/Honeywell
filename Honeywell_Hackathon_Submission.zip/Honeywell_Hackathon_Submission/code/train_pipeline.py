"""
Complete Training Pipeline for Behavioral Anomaly Detection System
Runs end-to-end: data generation -> feature engineering -> model training -> evaluation
"""

import os
import sys
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import (classification_report, confusion_matrix, 
                             roc_auc_score, precision_recall_curve, f1_score)

# Import modules
from data_generator import SyntheticAccessLogGenerator
from feature_engineering import BehavioralFeatureExtractor
from ensemble_model import EnsembleAnomalyDetector, AnomalyExplainer

def run_pipeline():
    """Execute complete training pipeline"""
    
    print("=" * 70)
    print("AI-POWERED BEHAVIORAL ANOMALY DETECTION SYSTEM - TRAINING PIPELINE")
    print("=" * 70)
    
    # Step 1: Generate Synthetic Data
    print("\n[1/5] GENERATING SYNTHETIC DATA")
    print("-" * 70)
    
    generator = SyntheticAccessLogGenerator(seed=42)
    df = generator.generate_dataset(n_normal=2000)
    
    # Save raw data
    os.makedirs('data', exist_ok=True)
    df.to_csv('data/access_logs.csv', index=False)
    print(f"✓ Raw data saved to data/access_logs.csv")
    
    # Step 2: Feature Engineering
    print("\n[2/5] FEATURE ENGINEERING")
    print("-" * 70)
    
    extractor = BehavioralFeatureExtractor()
    df_features = extractor.extract_all_features(df)
    
    X, y, X_raw = extractor.prepare_for_modeling(df_features)
    print(f"✓ {X.shape[1]} features extracted from {X.shape[0]} samples")
    print(f"✓ Anomaly rate: {y.sum() / len(y) * 100:.1f}%")
    
    # Step 3: Train/Test Split
    print("\n[3/5] SPLITTING DATA")
    print("-" * 70)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"✓ Training set: {X_train.shape[0]} samples ({(y_train==1).sum()} anomalies)")
    print(f"✓ Test set: {X_test.shape[0]} samples ({(y_test==1).sum()} anomalies)")
    
    # Step 4: Train Ensemble Model
    print("\n[4/5] TRAINING ENSEMBLE MODEL")
    print("-" * 70)
    
    detector = EnsembleAnomalyDetector(contamination=0.15)
    detector.fit(X_train, y_train)
    
    # Step 5: Evaluation
    print("\n[5/5] EVALUATING MODEL")
    print("-" * 70)
    
    y_pred, y_scores = detector.predict(X_test)
    
    # Metrics
    auc_score = roc_auc_score(y_test, y_scores)
    f1 = f1_score(y_test, y_pred)
    
    print(f"\n✓ AUC-ROC Score: {auc_score:.3f}")
    print(f"✓ F1-Score: {f1:.3f}")
    print(f"\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Normal', 'Anomaly']))
    
    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    
    print(f"\nConfusion Matrix:")
    print(f"  True Negatives:  {tn}")
    print(f"  False Positives: {fp}")
    print(f"  False Negatives: {fn}")
    print(f"  True Positives:  {tp}")
    
    # Precision, Recall, Specificity
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    
    print(f"\nDetailed Metrics:")
    print(f"  Precision (TP/(TP+FP)):  {precision:.3f}")
    print(f"  Recall (TP/(TP+FN)):     {recall:.3f}")
    print(f"  Specificity (TN/(TN+FP)): {specificity:.3f}")
    
    # Feature Importance
    print(f"\nFeature Importance (Top 10):")
    importance_df = detector.get_feature_importance(extractor.feature_names)
    if importance_df is not None:
        for idx, row in importance_df.head(10).iterrows():
            print(f"  {idx+1}. {row['feature']:.<40} {row['importance']:.4f}")
    
    # Save Model
    os.makedirs('models', exist_ok=True)
    detector.save('models/ensemble_detector.pkl')
    
    # Save Results Summary
    results_summary = {
        'Training Results': {
            'Total Samples': len(df),
            'Normal Samples': (y == 0).sum(),
            'Anomaly Samples': (y == 1).sum(),
            'Anomaly Rate': f"{y.sum() / len(y) * 100:.2f}%"
        },
        'Model Performance': {
            'AUC-ROC': f"{auc_score:.3f}",
            'F1-Score': f"{f1:.3f}",
            'Accuracy': f"{(y_pred == y_test).sum() / len(y_test):.3f}",
            'Precision': f"{precision:.3f}",
            'Recall': f"{recall:.3f}",
            'Specificity': f"{specificity:.3f}"
        }
    }
    
    # Save as JSON
    import json
    with open('models/results.json', 'w') as f:
        json.dump(results_summary, f, indent=2, default=str)
    
    print(f"\n✓ Results saved to models/results.json")
    
    # Test with sample predictions
    print("\n" + "=" * 70)
    print("SAMPLE PREDICTIONS (First 5 Test Samples)")
    print("=" * 70)
    
    explainer = AnomalyExplainer(extractor.feature_names, extractor.scaler)
    
    y_test_array = y_test.values if hasattr(y_test, 'values') else y_test
    for i in range(min(5, len(X_test))):
        pred = y_pred[i]
        score = y_scores[i]
        true_label = y_test_array[i]
        
        explanation = explainer.explain_prediction(X_test[i], pred, score)
        
        print(f"\nSample {i+1}:")
        print(f"  True Label: {'ANOMALY' if true_label == 1 else 'NORMAL'}")
        print(f"  Prediction: {explanation['prediction']}")
        print(f"  Confidence: {explanation['confidence']}")
        print(f"  Contributing Factors:")
        for factor in explanation['contributing_factors'][:3]:
            print(f"    - {factor['feature']}: {factor['value']}")
    
    print("\n" + "=" * 70)
    print("✓ TRAINING PIPELINE COMPLETED SUCCESSFULLY")
    print("=" * 70)
    
    return detector, extractor, df, results_summary


if __name__ == "__main__":
    detector, extractor, df, results = run_pipeline()
