#!/usr/bin/env python3
"""
Main Entry Point - Honeywell Behavioral Anomaly Detection System
Orchestrates the complete ML pipeline: data generation → training → inference
"""

import argparse
import sys
import os
from pathlib import Path

# Add code directory to path
sys.path.insert(0, str(Path(__file__).parent / "code"))

from code.data_generator import SyntheticAccessLogGenerator
from code.feature_engineering import BehavioralFeatureExtractor
from code.ensemble_model import EnsembleAnomalyDetector
from train_pipeline import run_pipeline


def main():
    parser = argparse.ArgumentParser(
        description="Honeywell Behavioral Anomaly Detection System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run complete training pipeline
  python3 main.py --train

  # Launch interactive dashboard
  python3 main.py --dashboard

  # Generate synthetic data only
  python3 main.py --generate-data

  # Make predictions on new data
  python3 main.py --predict --input data/new_logs.csv
        """
    )
    
    parser.add_argument(
        "--train",
        action="store_true",
        help="Run complete training pipeline"
    )
    
    parser.add_argument(
        "--dashboard",
        action="store_true",
        help="Launch Streamlit dashboard"
    )
    
    parser.add_argument(
        "--generate-data",
        action="store_true",
        help="Generate synthetic data only"
    )
    
    parser.add_argument(
        "--predict",
        action="store_true",
        help="Make predictions on new data"
    )
    
    parser.add_argument(
        "--input",
        type=str,
        default="data/access_logs.csv",
        help="Input file path for predictions"
    )
    
    parser.add_argument(
        "--output",
        type=str,
        default="output/predictions.csv",
        help="Output file path for predictions"
    )
    
    parser.add_argument(
        "--model",
        type=str,
        default="models/ensemble_detector.pkl",
        help="Path to trained model"
    )
    
    args = parser.parse_args()
    
    if args.train:
        print("\n" + "="*70)
        print("RUNNING COMPLETE TRAINING PIPELINE")
        print("="*70)
        run_pipeline()
        
    elif args.dashboard:
        print("\n" + "="*70)
        print("LAUNCHING STREAMLIT DASHBOARD")
        print("="*70)
        os.system("streamlit run code/app.py")
        
    elif args.generate_data:
        print("\n" + "="*70)
        print("GENERATING SYNTHETIC DATA")
        print("="*70)
        generator = SyntheticAccessLogGenerator(seed=42)
        df = generator.generate_dataset(n_normal=2000)
        df.to_csv("data/access_logs.csv", index=False)
        print(f"✓ Data saved to data/access_logs.csv")
        
    elif args.predict:
        print("\n" + "="*70)
        print("MAKING PREDICTIONS")
        print("="*70)
        
        import pandas as pd
        from code.feature_engineering import BehavioralFeatureExtractor
        from code.ensemble_model import EnsembleAnomalyDetector
        
        # Load data
        df = pd.read_csv(args.input)
        print(f"✓ Loaded {len(df)} records from {args.input}")
        
        # Load model
        detector = EnsembleAnomalyDetector()
        detector.load(args.model)
        print(f"✓ Loaded model from {args.model}")
        
        # Extract features
        extractor = BehavioralFeatureExtractor()
        df_features = extractor.extract_all_features(df)
        X, _, _ = extractor.prepare_for_modeling(df_features, fit=False)
        
        # Make predictions
        predictions, scores = detector.predict(X)
        
        # Save results
        results = pd.DataFrame({
            'entity_id': df['entity_id'],
            'timestamp': df['timestamp'],
            'prediction': predictions,
            'anomaly_score': scores,
            'risk_level': pd.cut(scores, bins=[0, 0.3, 0.5, 0.7, 1.0],
                                labels=['low', 'medium', 'high', 'critical'])
        })
        
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        results.to_csv(args.output, index=False)
        print(f"✓ Predictions saved to {args.output}")
        print(f"\nSummary:")
        print(f"  Normal events: {(predictions == 0).sum()}")
        print(f"  Anomalies: {(predictions == 1).sum()}")
        print(f"  Average risk score: {scores.mean():.3f}")
        
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
