# 📁 Project Structure - AI/ML System for Behavioral Anomaly Detection

```
Honeywell_Hackathon_Submission/
│
├── 📄 README.md                          [START HERE - Complete guide]
├── 📄 setup.py                           [Package installation]
├── 📄 main.py                            [Main entry point]
├── 📄 requirements.txt                   [Python dependencies]
├── 📄 train_pipeline.py                  [Training orchestrator]
├── 📄 .gitignore                         [Git configuration]
│
├── 📂 code/                              [Source code (production quality)]
│   ├── __init__.py                       [Package initialization]
│   ├── data_generator.py                 [Synthetic data generation]
│   │   └── SyntheticAccessLogGenerator   [8 attack patterns, 2,735 logs]
│   │
│   ├── feature_engineering.py            [Feature extraction pipeline]
│   │   ├── BehavioralFeatureExtractor    [24 engineered features]
│   │   └── AnomalyExplainer              [Per-event explanations]
│   │
│   ├── ensemble_model.py                 [ML ensemble system]
│   │   ├── EnsembleAnomalyDetector       [IF + XGBoost]
│   │   └── AnomalyExplainer              [Explainability layer]
│   │
│   └── app.py                            [Streamlit dashboard]
│       ├── System Overview               [KPIs, status, timeline]
│       ├── Anomaly Detection             [Live threats, details]
│       ├── Analytics                     [Performance metrics]
│       └── Real-Time Alerts              [Alert stream]
│
├── 📂 data/                              [Datasets]
│   └── access_logs.csv                   [2,735 synthetic logs (8 patterns)]
│       ├── 2,000 normal baselines
│       ├── 150 brute force
│       ├── 80 impossible travel
│       ├── 120 credential stuffing
│       ├── 100 lateral movement
│       ├── 90 device spoofing
│       ├── 110 low-slow exfiltration
│       └── 85 insider drift
│
├── 📂 models/                            [Trained models]
│   ├── ensemble_detector.pkl             [Trained model (99.8% AUC)]
│   └── results.json                      [Training metrics & results]
│
├── 📂 docs/                              [Documentation & reports]
│   ├── README.md                         [Complete setup & architecture]
│   ├── Honeywell_Hackathon_Submission.pptx [6-slide presentation]
│   ├── Honeywell_Project_Report.pdf      [50-page technical report]
│   ├── SUBMISSION_SUMMARY.txt            [Detailed overview]
│   └── QUICK_REFERENCE.txt               [2-minute quick start]
│
├── 📂 config/                            [Configuration files]
│   └── config.yaml                       [Model & system parameters]
│
└── 📂 notebooks/                         [Jupyter notebooks (optional)]
    ├── 01_data_exploration.ipynb         [EDA & visualization]
    ├── 02_feature_analysis.ipynb         [Feature importance]
    └── 03_model_evaluation.ipynb         [Performance analysis]
```

---

## 📋 File Descriptions

### Root Level

| File | Purpose |
|------|---------|
| `README.md` | Complete project documentation with setup, architecture, and usage |
| `main.py` | CLI entry point with subcommands (train, dashboard, predict, generate-data) |
| `setup.py` | Package configuration for pip installation |
| `requirements.txt` | Python package dependencies |
| `train_pipeline.py` | End-to-end training pipeline orchestrator |
| `.gitignore` | Git configuration (ignore __pycache__, .env, etc.) |

### 📂 code/ - Source Code (Production Quality)

**Core Modules:**

#### `data_generator.py`
- **Class:** `SyntheticAccessLogGenerator`
- **Purpose:** Generate realistic synthetic access logs with 8 attack patterns
- **Methods:**
  - `generate_dataset(n_normal)` - Create full dataset
  - `generate_normal_baseline()` - Regular business behavior
  - `generate_brute_force()` - Rapid auth attempts
  - `generate_impossible_travel()` - Geographic impossibilities
  - `generate_credential_stuffing()` - Mass account trials
  - `generate_lateral_movement()` - Unusual resource access
  - `generate_device_spoofing()` - Fingerprint mismatches
  - `generate_low_slow_exfiltration()` - Gradual data theft
  - `generate_insider_drift()` - Privilege creep
- **Output:** 2,735 CSV records with 11 columns

#### `feature_engineering.py`
- **Class:** `BehavioralFeatureExtractor`
- **Purpose:** Extract 24 behavioral features from raw access logs
- **Features Extracted:**
  - **Temporal (4):** hour_of_day, day_of_week, is_business_hours, is_weekend
  - **Entity-Behavioral (9):** access_frequency, location_diversity, resource_diversity, etc.
  - **Contextual (4):** unusual_auth, rare_resource, suspicious_command, location_shift
  - **Sequence-Based (3):** time_since_last_access, access_count_24h, session_anomaly
  - **Encoded (3):** entity_type_encoded, auth_method_encoded, protocol_encoded
  - **Raw (1):** session_duration_mins
- **Methods:**
  - `extract_all_features()` - Extract all 24 features
  - `prepare_for_modeling()` - Normalize & format for ML
  - `get_feature_columns()` - List feature names

- **Class:** `AnomalyExplainer`
- **Purpose:** Generate per-prediction explanations
- **Methods:**
  - `explain_prediction()` - Identify contributing factors for each anomaly

#### `ensemble_model.py`
- **Class:** `EnsembleAnomalyDetector`
- **Purpose:** Two-stage ensemble combining Isolation Forest + XGBoost
- **Architecture:**
  - Stage 1: Isolation Forest (unsupervised anomaly scoring)
  - Stage 2: XGBoost (supervised calibration & classification)
- **Models:**
  - `isolation_forest` - IF with contamination=0.15, n_estimators=100
  - `xgboost_classifier` - XGB with max_depth=6, scale_pos_weight=5
- **Methods:**
  - `fit(X_train, y_train)` - Train ensemble on labeled data
  - `predict(X)` - Get predictions and anomaly scores
  - `classify_anomaly(scores)` - Classify anomaly type
  - `get_feature_importance()` - Extract feature importances
  - `save(filepath)` - Serialize trained model
  - `load(filepath)` - Deserialize model

#### `app.py`
- **Framework:** Streamlit
- **Tabs:**
  1. **System Overview** - KPIs, system status, timeline
  2. **Anomaly Detection** - Live threats, geographic distribution
  3. **Analytics** - Model performance, ROC curves, feature importance
  4. **Real-Time Alerts** - Simulated threat stream
- **Features:**
  - Interactive filtering & drill-down
  - Real-time metrics & charts
  - Alert severity levels (low/medium/high/critical)

### 📂 data/ - Datasets

- **access_logs.csv** (300 KB)
  - 2,735 synthetic access log records
  - 11 columns: entity_id, entity_type, timestamp, source_ip, geo_location, resource_accessed, auth_method, protocol, session_duration_mins, command_sequence, device_fingerprint, label
  - 8 attack pattern labels
  - Train/test split: 80/20 (2,188 train, 547 test)

### 📂 models/ - Trained Models

- **ensemble_detector.pkl** (1.7 MB)
  - Fully trained Isolation Forest + XGBoost ensemble
  - Achieved 99.8% AUC-ROC on test set
  - Ready for inference on new data
  - Format: Python pickle (binary)

- **results.json** (< 1 KB)
  - Training metrics summary:
    - AUC-ROC: 0.998
    - Recall: 0.993
    - Precision: 0.918
    - F1-Score: 0.954
    - Accuracy: 0.973

### 📂 docs/ - Documentation

- **README.md** - Complete setup & architecture guide
- **Honeywell_Hackathon_Submission.pptx** - 6-slide presentation
- **Honeywell_Project_Report.pdf** - 50-page technical report
- **SUBMISSION_SUMMARY.txt** - Detailed project overview
- **QUICK_REFERENCE.txt** - 2-minute quick start

### 📂 config/ - Configuration

- **config.yaml**
  - Data generation parameters (n_samples, attack type counts)
  - Feature engineering settings (scaling, n_features)
  - Model hyperparameters (IF, XGBoost)
  - Training configuration (test_size, validation_split)
  - Path configuration (data_dir, model_dir, output_dir)
  - Logging configuration

### 📂 notebooks/ - Jupyter Notebooks (Optional)

- **01_data_exploration.ipynb** - EDA, data visualization
- **02_feature_analysis.ipynb** - Feature importance, distributions
- **03_model_evaluation.ipynb** - Performance metrics, confusion matrix

---

## 🚀 Quick Reference

### Installation
```bash
pip install -r requirements.txt
# or
python setup.py install
```

### Training
```bash
python main.py --train
# Generates data → Extracts features → Trains models (99.8% AUC)
```

### Dashboard
```bash
python main.py --dashboard
# Opens interactive Streamlit app at localhost:8501
```

### Make Predictions
```bash
python main.py --predict --input data/new_logs.csv --output output/predictions.csv
```

### Generate Data Only
```bash
python main.py --generate-data
```

---

## 📊 Key Metrics

| Metric | Value |
|--------|-------|
| **AUC-ROC** | 99.8% |
| **Recall** | 99.3% |
| **Precision** | 91.8% |
| **F1-Score** | 95.4% |
| **Accuracy** | 97.3% |
| **Training Time** | ~2 minutes |
| **Inference Speed** | <100ms per event |
| **Attack Patterns** | 8 types |
| **Features Engineered** | 24 |

---

## 🔍 File Sizes

| Component | Size |
|-----------|------|
| Source Code (7 files) | ~100 KB |
| Synthetic Data | 300 KB |
| Trained Model | 1.7 MB |
| Documentation | 70 KB |
| **Total Package** | **~2.2 MB** |

---

## ✅ Submission Checklist

- ✅ All source code (.py files)
- ✅ Trained model (ensemble_detector.pkl)
- ✅ Synthetic dataset (access_logs.csv)
- ✅ Professional presentation (6 slides)
- ✅ Technical report (50 pages)
- ✅ Configuration files (config.yaml)
- ✅ Package setup (setup.py)
- ✅ Main entry point (main.py)
- ✅ Comprehensive documentation
- ✅ Requirements file

**Status: ✅ COMPLETE & READY FOR SUBMISSION**

---

## 📞 Support

- **GitHub:** github.com/tanishirai
- **LinkedIn:** linkedin.com/in/tanishi-rai
- **Email:** tanishi.rai@vitbhopal.ac.in

---

**Last Updated:** July 25, 2026 | **Version:** 1.0.0
